package pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Anzpageobjects {

@FindBy(id="application_type_single")
public static WebElement ApplicationType;

@FindBy(xpath="//*[@id=\"main-container\"]/div[1]/div/div/div[2]/div/div/div/div/div[1]/div/div[2]/div/div[1]/div/div[2]/div/select")
public static WebElement Dependents;

@FindBy(id="borrow_type_home")
public static WebElement LivingType;

@FindBy(xpath="//label[contains(text(),'Your income')]/following::div[1]/child::input")
public static WebElement Firstincome;

@FindBy(xpath="//label[text()='Your other income']/following::div[1]/child::input")
public static WebElement FirstOtherincome;

@FindBy(id="expenses")
public static WebElement LivingExpense;

@FindBy(id="homeloans")
public static WebElement Homeloan;

@FindBy(id="otherloans")
public static WebElement Otherloan;

@FindBy(xpath="//label[@id='q3q4']/following::div[1]/child::input")
public static WebElement Othercommitments;

@FindBy(id="credit")
public static WebElement credtcardlimit;

@FindBy(id="btnBorrowCalculater")
public static WebElement BorrowcalculatorButton;

@FindBy(id="borrowResultTextAmount")
public static WebElement BorrowEstimate;

@FindBy(className="borrow__error__text")
public static WebElement Borrowinfomessage;

@FindBy(xpath="//label[@id='q2q3']/following-sibling::div[1]/child::input[1]")
public static WebElement Secondincome;

@FindBy(xpath="//label[@id='q2q4']/following-sibling::div[1]/child::input[1]")
public static WebElement Secondotherincome;

@FindBy(className="start-over")
public static WebElement StartOver;



}
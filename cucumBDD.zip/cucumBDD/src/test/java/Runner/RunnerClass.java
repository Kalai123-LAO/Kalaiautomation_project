package Runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="Featurefiles/FirstTest.feature", 
				 glue={"StepDefine","ANZBorrowEstimate"},
				 plugin= {"pretty", "html:report/webreport.html"},
				 monochrome=true,
				 tags="@Testcases"
				)
public class RunnerClass {

}

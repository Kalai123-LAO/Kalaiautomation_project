package Runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="Featurefiles/ClearEstimate.feature", 
				 glue={"StepDefine","ANZBorrowEstimate"},
				 plugin= {"rerun:target/failed_scenarios.txt"},
				 monochrome=true,
				 tags="@Testcase2"
				)

public class FailedRun {

}
